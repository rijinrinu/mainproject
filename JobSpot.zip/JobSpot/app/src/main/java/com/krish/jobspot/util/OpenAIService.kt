package com.krish.jobspot.util

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


interface OpenAIService {
    @Headers("Authorization: Bearer 205FDaKF8UjBsRbroZSNXCVwq18MR9lf2TzZYrQSmlUCwE3fd7OAHa4VIO6pt0cQ") // Replace with your API key
    @POST("v1/completions")
    fun fetchSkillsFromResume(@Body requestBody: OpenAIRequest): Call<OpenAIResponse>
}

data class OpenAIRequest(val model: String,val prompt: String, val temperature: Double, val max_tokens: Int)

data class OpenAIResponse(val choices: List<Choice>)
data class Choice(val text: String)

object RetrofitClient {
    val retrofitInstance: Retrofit
        get() = Retrofit.Builder()
            .baseUrl("https://api.openai.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
}