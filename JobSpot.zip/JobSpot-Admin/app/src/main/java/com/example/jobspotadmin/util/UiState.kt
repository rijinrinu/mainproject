package com.example.jobspotadmin.util

enum class UiState {
    LOADING, SUCCESS, FAILURE
}