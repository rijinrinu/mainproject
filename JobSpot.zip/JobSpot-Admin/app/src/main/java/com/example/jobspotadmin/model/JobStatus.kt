package com.example.jobspotadmin.model

data class JobStatus(
    var student: Student = Student(),
    var jobApplication: JobApplication = JobApplication()
)
